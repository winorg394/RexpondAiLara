<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Auth\OAuthController;
use App\Http\Controllers\GoogleAuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Public routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// OTP Authentication Routes
Route::post('/auth/otp/send', [AuthController::class, 'sendOtp']);
Route::post('/auth/otp/verify', [AuthController::class, 'verifyOtp']);
Route::post('/auth/register-with-otp', [AuthController::class, 'registerWithOtp']);
Route::post('/auth/login-with-otp', [AuthController::class, 'loginWithOtp']);

// Password Reset Routes
Route::post('/auth/password/otp', [AuthController::class, 'sendPasswordResetOtp']);
Route::post('/auth/password/reset', [AuthController::class, 'resetPasswordWithOtp']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::get('/me', [AuthController::class, 'me']);
});

 
// Google OAuth Routes
Route::get('/auth/redirect', [OAuthController::class, 'redirectToGoogle']);

// Google Gmail Import Routes
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/auth/google/import', [GoogleAuthController::class, 'redirectToGoogle']);
    Route::get('/emails', [GoogleAuthController::class, 'getEmails']);
    Route::get('/emails/unread', [GoogleAuthController::class, 'getUnreadEmails']);
});
Route::get('/auth/google/import/callback', [GoogleAuthController::class, 'handleGoogleCallback']);

