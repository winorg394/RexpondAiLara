import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
export const redirectToGoogle = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle.url(options),
    method: 'get',
})

redirectToGoogle.definition = {
    methods: ["get","head"],
    url: '/api/auth/google/import',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
redirectToGoogle.url = (options?: RouteQueryOptions) => {
    return redirectToGoogle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
redirectToGoogle.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
redirectToGoogle.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToGoogle.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
    const redirectToGoogleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirectToGoogle.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
        redirectToGoogleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGoogle.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GoogleAuthController::redirectToGoogle
 * @see app/Http/Controllers/GoogleAuthController.php:13
 * @route '/api/auth/google/import'
 */
        redirectToGoogleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGoogle.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirectToGoogle.form = redirectToGoogleForm
/**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
export const getEmails = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmails.url(options),
    method: 'get',
})

getEmails.definition = {
    methods: ["get","head"],
    url: '/api/emails',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
getEmails.url = (options?: RouteQueryOptions) => {
    return getEmails.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
getEmails.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmails.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
getEmails.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmails.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
    const getEmailsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmails.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
        getEmailsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmails.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GoogleAuthController::getEmails
 * @see app/Http/Controllers/GoogleAuthController.php:107
 * @route '/api/emails'
 */
        getEmailsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmails.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmails.form = getEmailsForm
/**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
export const getUnreadEmails = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUnreadEmails.url(options),
    method: 'get',
})

getUnreadEmails.definition = {
    methods: ["get","head"],
    url: '/api/emails/unread',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
getUnreadEmails.url = (options?: RouteQueryOptions) => {
    return getUnreadEmails.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
getUnreadEmails.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUnreadEmails.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
getUnreadEmails.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUnreadEmails.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
    const getUnreadEmailsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getUnreadEmails.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
        getUnreadEmailsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUnreadEmails.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GoogleAuthController::getUnreadEmails
 * @see app/Http/Controllers/GoogleAuthController.php:172
 * @route '/api/emails/unread'
 */
        getUnreadEmailsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUnreadEmails.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getUnreadEmails.form = getUnreadEmailsForm
/**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
export const handleGoogleCallback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGoogleCallback.url(options),
    method: 'get',
})

handleGoogleCallback.definition = {
    methods: ["get","head"],
    url: '/api/auth/google/import/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
handleGoogleCallback.url = (options?: RouteQueryOptions) => {
    return handleGoogleCallback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
handleGoogleCallback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGoogleCallback.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
handleGoogleCallback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: handleGoogleCallback.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
    const handleGoogleCallbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: handleGoogleCallback.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
        handleGoogleCallbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: handleGoogleCallback.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GoogleAuthController::handleGoogleCallback
 * @see app/Http/Controllers/GoogleAuthController.php:33
 * @route '/api/auth/google/import/callback'
 */
        handleGoogleCallbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: handleGoogleCallback.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    handleGoogleCallback.form = handleGoogleCallbackForm
const GoogleAuthController = { redirectToGoogle, getEmails, getUnreadEmails, handleGoogleCallback }

export default GoogleAuthController