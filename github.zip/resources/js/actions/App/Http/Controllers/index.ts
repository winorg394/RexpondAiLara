import Api from './Api'
import Auth from './Auth'
import GoogleAuthController from './GoogleAuthController'
import Settings from './Settings'
const Controllers = {
    Api,
Auth,
GoogleAuthController,
Settings,
}

export default Controllers