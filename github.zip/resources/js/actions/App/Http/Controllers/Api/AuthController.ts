import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AuthController::register
 * @see app/Http/Controllers/Api/AuthController.php:22
 * @route '/api/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::register
 * @see app/Http/Controllers/Api/AuthController.php:22
 * @route '/api/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::register
 * @see app/Http/Controllers/Api/AuthController.php:22
 * @route '/api/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::register
 * @see app/Http/Controllers/Api/AuthController.php:22
 * @route '/api/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::register
 * @see app/Http/Controllers/Api/AuthController.php:22
 * @route '/api/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
/**
* @see \App\Http\Controllers\Api\AuthController::login
 * @see app/Http/Controllers/Api/AuthController.php:59
 * @route '/api/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::login
 * @see app/Http/Controllers/Api/AuthController.php:59
 * @route '/api/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::login
 * @see app/Http/Controllers/Api/AuthController.php:59
 * @route '/api/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::login
 * @see app/Http/Controllers/Api/AuthController.php:59
 * @route '/api/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::login
 * @see app/Http/Controllers/Api/AuthController.php:59
 * @route '/api/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Api\AuthController::sendOtp
 * @see app/Http/Controllers/Api/AuthController.php:133
 * @route '/api/auth/otp/send'
 */
export const sendOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendOtp.url(options),
    method: 'post',
})

sendOtp.definition = {
    methods: ["post"],
    url: '/api/auth/otp/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::sendOtp
 * @see app/Http/Controllers/Api/AuthController.php:133
 * @route '/api/auth/otp/send'
 */
sendOtp.url = (options?: RouteQueryOptions) => {
    return sendOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::sendOtp
 * @see app/Http/Controllers/Api/AuthController.php:133
 * @route '/api/auth/otp/send'
 */
sendOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::sendOtp
 * @see app/Http/Controllers/Api/AuthController.php:133
 * @route '/api/auth/otp/send'
 */
    const sendOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::sendOtp
 * @see app/Http/Controllers/Api/AuthController.php:133
 * @route '/api/auth/otp/send'
 */
        sendOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendOtp.url(options),
            method: 'post',
        })
    
    sendOtp.form = sendOtpForm
/**
* @see \App\Http\Controllers\Api\AuthController::verifyOtp
 * @see app/Http/Controllers/Api/AuthController.php:160
 * @route '/api/auth/otp/verify'
 */
export const verifyOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyOtp.url(options),
    method: 'post',
})

verifyOtp.definition = {
    methods: ["post"],
    url: '/api/auth/otp/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::verifyOtp
 * @see app/Http/Controllers/Api/AuthController.php:160
 * @route '/api/auth/otp/verify'
 */
verifyOtp.url = (options?: RouteQueryOptions) => {
    return verifyOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::verifyOtp
 * @see app/Http/Controllers/Api/AuthController.php:160
 * @route '/api/auth/otp/verify'
 */
verifyOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::verifyOtp
 * @see app/Http/Controllers/Api/AuthController.php:160
 * @route '/api/auth/otp/verify'
 */
    const verifyOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::verifyOtp
 * @see app/Http/Controllers/Api/AuthController.php:160
 * @route '/api/auth/otp/verify'
 */
        verifyOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyOtp.url(options),
            method: 'post',
        })
    
    verifyOtp.form = verifyOtpForm
/**
* @see \App\Http\Controllers\Api\AuthController::registerWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:201
 * @route '/api/auth/register-with-otp'
 */
export const registerWithOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registerWithOtp.url(options),
    method: 'post',
})

registerWithOtp.definition = {
    methods: ["post"],
    url: '/api/auth/register-with-otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::registerWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:201
 * @route '/api/auth/register-with-otp'
 */
registerWithOtp.url = (options?: RouteQueryOptions) => {
    return registerWithOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::registerWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:201
 * @route '/api/auth/register-with-otp'
 */
registerWithOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registerWithOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::registerWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:201
 * @route '/api/auth/register-with-otp'
 */
    const registerWithOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: registerWithOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::registerWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:201
 * @route '/api/auth/register-with-otp'
 */
        registerWithOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: registerWithOtp.url(options),
            method: 'post',
        })
    
    registerWithOtp.form = registerWithOtpForm
/**
* @see \App\Http\Controllers\Api\AuthController::loginWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:260
 * @route '/api/auth/login-with-otp'
 */
export const loginWithOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loginWithOtp.url(options),
    method: 'post',
})

loginWithOtp.definition = {
    methods: ["post"],
    url: '/api/auth/login-with-otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::loginWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:260
 * @route '/api/auth/login-with-otp'
 */
loginWithOtp.url = (options?: RouteQueryOptions) => {
    return loginWithOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::loginWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:260
 * @route '/api/auth/login-with-otp'
 */
loginWithOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loginWithOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::loginWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:260
 * @route '/api/auth/login-with-otp'
 */
    const loginWithOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: loginWithOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::loginWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:260
 * @route '/api/auth/login-with-otp'
 */
        loginWithOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: loginWithOtp.url(options),
            method: 'post',
        })
    
    loginWithOtp.form = loginWithOtpForm
/**
* @see \App\Http\Controllers\Api\AuthController::sendPasswordResetOtp
 * @see app/Http/Controllers/Api/AuthController.php:294
 * @route '/api/auth/password/otp'
 */
export const sendPasswordResetOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendPasswordResetOtp.url(options),
    method: 'post',
})

sendPasswordResetOtp.definition = {
    methods: ["post"],
    url: '/api/auth/password/otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::sendPasswordResetOtp
 * @see app/Http/Controllers/Api/AuthController.php:294
 * @route '/api/auth/password/otp'
 */
sendPasswordResetOtp.url = (options?: RouteQueryOptions) => {
    return sendPasswordResetOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::sendPasswordResetOtp
 * @see app/Http/Controllers/Api/AuthController.php:294
 * @route '/api/auth/password/otp'
 */
sendPasswordResetOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendPasswordResetOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::sendPasswordResetOtp
 * @see app/Http/Controllers/Api/AuthController.php:294
 * @route '/api/auth/password/otp'
 */
    const sendPasswordResetOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendPasswordResetOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::sendPasswordResetOtp
 * @see app/Http/Controllers/Api/AuthController.php:294
 * @route '/api/auth/password/otp'
 */
        sendPasswordResetOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendPasswordResetOtp.url(options),
            method: 'post',
        })
    
    sendPasswordResetOtp.form = sendPasswordResetOtpForm
/**
* @see \App\Http\Controllers\Api\AuthController::resetPasswordWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:317
 * @route '/api/auth/password/reset'
 */
export const resetPasswordWithOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPasswordWithOtp.url(options),
    method: 'post',
})

resetPasswordWithOtp.definition = {
    methods: ["post"],
    url: '/api/auth/password/reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::resetPasswordWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:317
 * @route '/api/auth/password/reset'
 */
resetPasswordWithOtp.url = (options?: RouteQueryOptions) => {
    return resetPasswordWithOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::resetPasswordWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:317
 * @route '/api/auth/password/reset'
 */
resetPasswordWithOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPasswordWithOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::resetPasswordWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:317
 * @route '/api/auth/password/reset'
 */
    const resetPasswordWithOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetPasswordWithOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::resetPasswordWithOtp
 * @see app/Http/Controllers/Api/AuthController.php:317
 * @route '/api/auth/password/reset'
 */
        resetPasswordWithOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetPasswordWithOtp.url(options),
            method: 'post',
        })
    
    resetPasswordWithOtp.form = resetPasswordWithOtpForm
/**
* @see \App\Http\Controllers\Api\AuthController::logout
 * @see app/Http/Controllers/Api/AuthController.php:113
 * @route '/api/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::logout
 * @see app/Http/Controllers/Api/AuthController.php:113
 * @route '/api/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::logout
 * @see app/Http/Controllers/Api/AuthController.php:113
 * @route '/api/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::logout
 * @see app/Http/Controllers/Api/AuthController.php:113
 * @route '/api/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::logout
 * @see app/Http/Controllers/Api/AuthController.php:113
 * @route '/api/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\Api\AuthController::refresh
 * @see app/Http/Controllers/Api/AuthController.php:89
 * @route '/api/refresh'
 */
export const refresh = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refresh.url(options),
    method: 'post',
})

refresh.definition = {
    methods: ["post"],
    url: '/api/refresh',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::refresh
 * @see app/Http/Controllers/Api/AuthController.php:89
 * @route '/api/refresh'
 */
refresh.url = (options?: RouteQueryOptions) => {
    return refresh.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::refresh
 * @see app/Http/Controllers/Api/AuthController.php:89
 * @route '/api/refresh'
 */
refresh.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refresh.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::refresh
 * @see app/Http/Controllers/Api/AuthController.php:89
 * @route '/api/refresh'
 */
    const refreshForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: refresh.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::refresh
 * @see app/Http/Controllers/Api/AuthController.php:89
 * @route '/api/refresh'
 */
        refreshForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: refresh.url(options),
            method: 'post',
        })
    
    refresh.form = refreshForm
/**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
export const me = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

me.definition = {
    methods: ["get","head"],
    url: '/api/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
me.url = (options?: RouteQueryOptions) => {
    return me.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
me.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
me.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
    const meForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: me.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
        meForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\AuthController::me
 * @see app/Http/Controllers/Api/AuthController.php:123
 * @route '/api/me'
 */
        meForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    me.form = meForm
const AuthController = { register, login, sendOtp, verifyOtp, registerWithOtp, loginWithOtp, sendPasswordResetOtp, resetPasswordWithOtp, logout, refresh, me }

export default AuthController