import AuthController from './AuthController'
const Api = {
    AuthController,
}

export default Api