import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
const redirectToGoogle0840e24f11a8b70f1c762c6d27a15374 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url(options),
    method: 'get',
})

redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.definition = {
    methods: ["get","head"],
    url: '/api/auth/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url = (options?: RouteQueryOptions) => {
    return redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
    const redirectToGoogle0840e24f11a8b70f1c762c6d27a15374Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
        redirectToGoogle0840e24f11a8b70f1c762c6d27a15374Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/api/auth/redirect'
 */
        redirectToGoogle0840e24f11a8b70f1c762c6d27a15374Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirectToGoogle0840e24f11a8b70f1c762c6d27a15374.form = redirectToGoogle0840e24f11a8b70f1c762c6d27a15374Form
    /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
const redirectToGoogle1d72e6bda28849321a012ea52359e93f = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle1d72e6bda28849321a012ea52359e93f.url(options),
    method: 'get',
})

redirectToGoogle1d72e6bda28849321a012ea52359e93f.definition = {
    methods: ["get","head"],
    url: '/auth/google',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
redirectToGoogle1d72e6bda28849321a012ea52359e93f.url = (options?: RouteQueryOptions) => {
    return redirectToGoogle1d72e6bda28849321a012ea52359e93f.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
redirectToGoogle1d72e6bda28849321a012ea52359e93f.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle1d72e6bda28849321a012ea52359e93f.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
redirectToGoogle1d72e6bda28849321a012ea52359e93f.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToGoogle1d72e6bda28849321a012ea52359e93f.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
    const redirectToGoogle1d72e6bda28849321a012ea52359e93fForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirectToGoogle1d72e6bda28849321a012ea52359e93f.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
        redirectToGoogle1d72e6bda28849321a012ea52359e93fForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGoogle1d72e6bda28849321a012ea52359e93f.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\OAuthController::redirectToGoogle
 * @see app/Http/Controllers/Auth/OAuthController.php:20
 * @route '/auth/google'
 */
        redirectToGoogle1d72e6bda28849321a012ea52359e93fForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGoogle1d72e6bda28849321a012ea52359e93f.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirectToGoogle1d72e6bda28849321a012ea52359e93f.form = redirectToGoogle1d72e6bda28849321a012ea52359e93fForm

export const redirectToGoogle = {
    '/api/auth/redirect': redirectToGoogle0840e24f11a8b70f1c762c6d27a15374,
    '/auth/google': redirectToGoogle1d72e6bda28849321a012ea52359e93f,
}

/**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
export const handleGoogleCallback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGoogleCallback.url(options),
    method: 'get',
})

handleGoogleCallback.definition = {
    methods: ["get","head"],
    url: '/auth/google/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
handleGoogleCallback.url = (options?: RouteQueryOptions) => {
    return handleGoogleCallback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
handleGoogleCallback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGoogleCallback.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
handleGoogleCallback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: handleGoogleCallback.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
    const handleGoogleCallbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: handleGoogleCallback.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
        handleGoogleCallbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: handleGoogleCallback.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\OAuthController::handleGoogleCallback
 * @see app/Http/Controllers/Auth/OAuthController.php:37
 * @route '/auth/google/callback'
 */
        handleGoogleCallbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: handleGoogleCallback.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    handleGoogleCallback.form = handleGoogleCallbackForm
const OAuthController = { redirectToGoogle, handleGoogleCallback }

export default OAuthController