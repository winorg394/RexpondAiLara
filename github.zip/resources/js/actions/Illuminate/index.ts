import Routing from './Routing'
const Illuminate = {
    Routing,
}

export default Illuminate