import RedirectController from './RedirectController'
const Routing = {
    RedirectController,
}

export default Routing