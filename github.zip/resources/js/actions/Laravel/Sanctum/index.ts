import Http from './Http'
const Sanctum = {
    Http,
}

export default Sanctum