import CsrfCookieController from './CsrfCookieController'
const Controllers = {
    CsrfCookieController,
}

export default Controllers