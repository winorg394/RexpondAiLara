import Sanctum from './Sanctum'
const Laravel = {
    Sanctum,
}

export default Laravel